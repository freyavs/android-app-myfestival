package com.example.myfestival

import androidx.lifecycle.ViewModel

class ConcertViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
